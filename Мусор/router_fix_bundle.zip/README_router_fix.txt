Roaccutane Tracker — фикс зацикливания онбординга
=========================================================

Что внутри:
- index.html — облегчённый ‘router-only’ с поддержкой derma_next.
  Он решает маршрут так:
  • если есть derma_next = profile|plan|main — идёт напрямую туда (без splash);
  • если нет согласия — splash → welcome-rt;
  • иначе по API: me → plan → main и всегда через splash ровно один раз.

Как применить:
1) Замените ваш index.html на приложенный (или перенесите в него блоки <script>).
2) Проверьте цепочку:
   - первый визит: /index.html?tg=1002&reset=1 → splash → welcome → warnings → profile → plan → main;
   - повторный визит: /index.html?tg=1002 → splash → main.
3) Убедитесь, что pages (warnings/profile/plan) после действия делают
   location.replace('./index.html' + (location.search||''))
   и выставляют derma_next: profile → plan → main соответственно.

Примечания:
- Если нужно, чтобы splash игрался на 1.5× и стартовал с +0.3s, адаптируйте splash-video.html как мы обсуждали ранее.
- Если вы убрали capsule_mg из UI, серверная ручка /api/plan должна принимать capsule_mg = NULL (мы уже дали пример).
